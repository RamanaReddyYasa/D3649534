package uk.ac.tees.mad.d3649534.navigation

interface NavigationDestination {
    val route: String
    val titleRes: Int
}