package uk.ac.tees.mad.d3649534.utils

const val ServerClient = "716819461459-s3snj552d3er9d9451cqdt4gu7amqem7.apps.googleusercontent.com"
